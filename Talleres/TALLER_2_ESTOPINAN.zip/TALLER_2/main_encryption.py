from crypto_functions import *
from main_decryption import *

# CONSTANTS & PARAMETERS
alpha       = 'ABCDEFGHIJKLMNOPQRSTUVWXYZ'
t           = 5           #Word's length

# MAIN ENTRY POINT
def main_encryption(KEY, PLAINTEXT):
    """ Entry point to ENCRYPT with Vignere Cipher"""
    # Display
    print("\n\t- Accept plaintexts in lower and upper case, with spaced words but NO other char than letters!")
    print("\t- Word's length =", t, "can be easily modified in code parameters\n")

    # Lists initialization
    L_plntxt   = cut_text(t, del_spaces(PLAINTEXT))
    L_key       = create_key_list(t, KEY, len(L_plntxt))
    L_cipher    = []

    #For each word
    for idx_w in range(len(L_plntxt)):
        L_txt_letters = list(L_plntxt[idx_w])
        L_key_letters = list(L_key[idx_w])

        L_cipher_word = []
        #For each letter
        for idx_l in range(t):
            plntxt_ind      = letter_ind(L_txt_letters[idx_l])
            key_ind         = letter_ind(L_key_letters[idx_l])
            # Encryption
            rot_alpha       = rotate(alpha, -key_ind)
            cipher_letter   = rot_alpha[plntxt_ind]
            # Cipher word construction
            L_cipher_word.append(cipher_letter)

        # Cipher list construction
        L_cipher.append(''.join(L_cipher_word))

    CIPHERTEXT = ' '.join(L_cipher)
    print("CIPHER_TEXT : ", CIPHERTEXT)