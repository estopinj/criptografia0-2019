from crypto_functions import *

# CONSTANTS & PARAMETERS
alpha       = 'ABCDEFGHIJKLMNOPQRSTUVWXYZ'
L_alpha     = list(alpha)

# MAIN ENTRY POINT
def main_decryption(KEY, CIPHERTEXT):
    """ Entry point to DECRYPT with Vignere Cipher"""
    # Lists initialization
    L_plntxt    = []
    L_cipher    = CIPHERTEXT.split()
    t           = len(L_cipher[1])                                      #Words' lenth determination
    L_key       = create_key_list(t, KEY, len(L_cipher))

    # Display
    print("\n\t- Accept ciphertexts in lower and upper case\n")

    #For each word
    for idx_w in range(len(L_cipher)):
        L_cipher_letters    = list(L_cipher[idx_w])
        L_key_letters       = list(L_key[idx_w])

        L_plntxt_word = []
        #For each letter
        for idx_l in range(t):
            cipher_letter   = L_cipher_letters[idx_l]
            key_ind         = letter_ind(L_key_letters[idx_l])
            # Decryption
            rot_alpha       = rotate(alpha, -key_ind)
            plntxt_ind      = rot_alpha.index(cipher_letter)
            plntxt_letter   = L_alpha[plntxt_ind]
            # Plaintext word construction
            L_plntxt_word.append(plntxt_letter)

        # Plaintext list construction
        L_plntxt.append(''.join(L_plntxt_word))

    PLAINTEXT = ' '.join(L_plntxt)
    print("PLAINTEXT : ", PLAINTEXT)