from collections import deque

def letter_ind(A):
    """ Return the index of the letter in A, lower o upper case. """
    return ord(A.upper()) - 65

def del_spaces(TEXT):
    """ Delete spaces in TEXT. """
    return ''.join(TEXT.split())

def cut_text(t, txt):
    """ Cut text in words of length t and return a list  of them. Complete eventually final word with As. """
    L = list()
    ind = 0
    while (ind+t)<=len(txt):        #Cut text in words of length t
        L.append(txt[ind:ind+t])
        ind+=t
    if ind<len(txt):                #Complete eventually final word with As
        f_word = txt[ind:]
        f_word += 'A'*(t-len(f_word))
        L.append(f_word)
    return L

def create_key_list(t, KEY, NB_w):
    """ Create the matching list of length-t words sliced into the repetition of KEY for VIGENERE Cipher. """
    key_rep = KEY.upper();
    while len(key_rep)<t*NB_w:
        key_rep+=KEY;
    L = cut_text(t,key_rep)
    return L[:NB_w]

def rotate(seq,r):
    """ Rotate a list using deque's method rotate. """
    col = deque(seq)
    col.rotate(r)
    return list(col)
