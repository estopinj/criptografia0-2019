from numpy import *
from crypto_functions import *

G = array([[1,0,0,0], [0,0,0,0], [0,1,0,1], [0,0,1,0]])
G2 = array([[0,1,0],[0,1,0],[1,0,0]])

def create_T_matrix(t, TEXT):
    """Returns matrix array of letters"""
    L_txt    = cut_text(t, del_spaces(TEXT))        # Separes TEXT in words of length t
    T_mat = []                                      # Final Turning Grille Matrix
    for i in range(t):
        L_line = []                                 # List containing letters of line i
        for l in L_txt[i]:
            L_line.append(l)
        T_mat.append(L_line)
    T_mat = array(T_mat)
    return T_mat

def grille_rotation(G, dir):
    """Returns a rotate grille in the direction dir"""
    t = shape(G)[0]
    G_new = zeros(shape(G))
    for i in range(t):
        if dir:         #Clockwize
            G_new[:,-(i+1)] = G[i,:]
        else:           #Counter-Clockwize
            G_new[:,i] = G[i,::-1]
    return G_new

def verif_grille(t, G):
    """Return 0 if grille is not conformable, 1 otherwise"""
    if size(G)!=(t*t):
        return 0
    else:                       # check if grille rotation causes cellules superposition
        G_sum = G[::]
        for i in range(1,4):    # use grille rotation
            G = grille_rotation(G,1)
            G_sum = add(G_sum,G)
        counter = 0
        for line in range(t):
            for column in range(t):
                if G_sum[line,column]>=2:
                    counter+=1
        if shape(G)[0]%2==1:    #Odd matrix : central element can be repeated
            if counter<=1:
                return 1
            else:
                return 0
        if shape(G)[0]%2==0:    #Pair matrix
            if counter==0:
                return 1
            else:
                return 0

def count_nbof1(G):
    t = shape(G)[0]
    counter = 0
    for line in range(t):
        for column in range(t):
            if G[line,column]==1:
                counter+=1
    return counter


def complete_mat_cipher(Mat_cipher, G, L_rot):
    """Return Mat_cipher completed with the letters in L_rot in the indicated position in Grille"""
    t = shape(G)[0]
    for line in range(t):
        for column in range(t):
            if G[line,column]==1:
                Mat_cipher[line,column] = L_rot.pop(0);
    if L_rot!=[]:
        print("Problem of numbers of letters/positions in the grille")
    return Mat_cipher


def read_mat_cipher(Mat_cipher, G):
    """Read the cipher matrix with a given grid G"""
    L_word = []
    t = shape(G)[0]
    for line in range(t):
        for column in range(t):
            if G[line,column]==1:
                L_word.append(Mat_cipher[line,column])
    word = ''.join(L_word)
    return word






























