from numpy import *
from crypto_functions import *
from turning_functions import *

# Grilles and texts used as test examples
G1      = array([[1,0,0,0], [0,0,0,0], [0,1,0,1], [0,0,1,0]])
text1   = "jima ttac ksat dawn"
cipher1 = "jktd saat wiam cnat"
G2      = array([[1,0,0,1,0,1,0,0,0],[0,0,1,0,0,0,0,0,1],[0,1,0,0,0,0,1,0,0],[0,0,1,0,1,0,0,1,0],[0,0,0,0,1,0,1,0,1],[0,0,0,1,0,0,0,1,0],[1,0,0,0,0,1,0,0,0],[0,1,0,0,1,0,0,0,1],[0,0,1,0,0,0,0,0,0]])
cipher2   = "TESHN INCIG LSRGY LRIUS PITSA TLILM REENS ATTOG SIAWG IPVER TOTEH HVAEA XITDT UAIME RANPM TLHIE"


# MAIN ENTRY POINT
def main_turning(t, dir, mode, G, TEXT):
    """ Entry point to Encrypt & Decrypt with Turning Grille Cipher
    Arguments :
    * t     = size of the grille
    * dir   = Rotation direction :  Clockwize   :1
                                    Counter     :0
    * mode  = Encryption    :0
            = Decryption    :1
    * G     = Matrix of 0 and 1 rep. the grille, size t²
    TEXT    = Message to Encrypt or Decrypt
    """
    # Display
    print("\n\t- Accept plaintexts in lower and upper case, with spaced words but NO other char than letters!")
    print("\n\t- Text's length must be smaller than t²")
    print("\n\t- Grille must be adequate")
    # Verifications
    G        = array(G)
    len_txt  = len(cut_text(1, del_spaces(TEXT)))
    if len_txt>(t*t):
        print("\n\t\t***Text's length longer than t²***")
    elif not(verif_grille(t, G)):
        print("\n\t\t***Grille's' format not adequate***")
    else:
        print("\n\t\t***Valid grille***")
        Nbof1       = count_nbof1(G)
        if mode==0:         #ENCRYPTION
            # Initialization
            L_txt       = cut_text(Nbof1, del_spaces(TEXT))
            Mat_cipher  = full((t,t),'0')
            L_cipher    = []
            #For each rotation
            for r in range(4):
                L_rot = list(L_txt[r])
                if r>=1:
                    G = grille_rotation(G,dir)
                # Complete Mat_cipher
                Mat_cipher = complete_mat_cipher(Mat_cipher, G, L_rot)

            for line in range(t):
                # Cipher list construction
                L_cipher.append(''.join(Mat_cipher[line,:]))
            # Final print
            CIPHERTEXT = ' '.join(L_cipher)
            print("CIPHER_TEXT : \n", CIPHERTEXT)

        else:               #DECRYPTION
            # Initialization
            Mat_cipher = create_T_matrix(t, TEXT)
            L_txt = []
            # For each rotation
            for r in range(4):
                if r>=1:
                    G = grille_rotation(G,dir)
                # Read Mat_cipher
                L_word = read_mat_cipher(Mat_cipher, G)
                L_txt.append(L_word)

            # Final print
            PLAINTEXT = ' '.join(L_txt)
            print("PLAIN_TEXT : \n",PLAINTEXT)



















